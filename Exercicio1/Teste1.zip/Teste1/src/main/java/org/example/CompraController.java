package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CompraController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto10;

    @FXML
    private TextField Texto2;

    @FXML
    private TextField Texto3;

    @FXML
    private TextField Texto4;

    @FXML
    private TextField Texto5;

    @FXML
    private TextField Texto6;

    @FXML
    private TextField Texto7;

    @FXML
    private TextField Texto8;

    @FXML
    private TextField Texto9;

    @FXML
    private Label lbdesconto;

    @FXML
    private Label lbtotal;

    @FXML
    private Label lbtotaldesc;

    @FXML
    void Botao1(ActionEvent event) {
        Compra c1 = new Compra(Double.parseDouble(Texto1.getText()),Double.parseDouble(Texto2.getText()),Double.parseDouble(Texto3.getText()),Double.parseDouble(Texto4.getText()),Double.parseDouble(Texto5.getText()),Double.parseDouble(Texto6.getText()),Double.parseDouble(Texto7.getText()),Double.parseDouble(Texto8.getText()),Double.parseDouble(Texto9.getText()),Double.parseDouble(Texto10.getText()));
        lbtotal.setText("R$: "+String.valueOf(c1.verificarSoma()));
        lbdesconto.setText("Valor da compra com desconto:");
        lbtotaldesc.setText("R$: "+String.valueOf(c1.verificarDesc()));
        Texto1.clear();
        Texto2.clear();
        Texto3.clear();
        Texto4.clear();
        Texto5.clear();
        Texto6.clear();
        Texto7.clear();
        Texto8.clear();
        Texto9.clear();
        Texto10.clear();
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
