package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;

public class AluguelController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private Label lbaluguel;

    @FXML
    void Botao1(ActionEvent event) {
        Aluguel a1 = new Aluguel(Integer.parseInt(Texto1.getText()),Double.parseDouble(Texto2.getText()));
        lbaluguel.setText("O total do aluguel será: R$ "+String.valueOf(a1.verificarAluguel()));
        Texto1.clear();
        Texto2.clear();

    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
