package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField Texto1;

    @FXML
    private Label lbresultado;

    @FXML
    void Botao1(ActionEvent event) {
        Login l1 = new Login(Integer.parseInt(Texto1.getText()));
        lbresultado.setText(l1.verificarSenha());
        Texto1.clear();
    }


    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
