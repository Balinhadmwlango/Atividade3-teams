package org.example;

public class Aluguel {
    private int dias;
    private double km,diaria,limite,pex,extra,r,r2;

    public Aluguel(int dias, double km){
        this.dias = dias;
        this.km = km;
        this.diaria = 5;
        this.limite = 10;
        this.pex = 7;
        this.extra = 0;
        this.r = 0;
        this.r2 = 0;
    }

    public double verificarAluguel(){
        this.r=this.dias*this.diaria;
        double preco = 0.0;
        if(this.km>this.limite){
            this.extra=(this.km-this.limite)*this.pex;
            this.r2=this.r+this.extra;
            preco = this.r2;
        }else{
            preco = this.r;
        }
        return (preco);
    }
}
