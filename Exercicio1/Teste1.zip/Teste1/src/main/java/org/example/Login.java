package org.example;
public class Login {
    private int senha;
    private int r;

    public Login(int r){
        this.r = r;
        this.senha = 1234;
    }

    public String verificarSenha() {
        if (this.r == this.senha){
            return ("Acesso permitido");
        }else{
            return ("Acesso negado");
        }
    }
}