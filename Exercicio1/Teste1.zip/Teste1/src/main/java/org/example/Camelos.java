package org.example;

public class Camelos {
    private int qtdtotal,r1,r2,r3;
    private float qtd1,qtd2,qtd3;

    public Camelos(int qtdtotal){
        this.qtdtotal = qtdtotal;
        this.qtd1 = 0;
        this.qtd2 = 0;
        this.qtd3 = 0;
        this.r1 = 0;
        this.r2 = 0;
        this.r3 = 0;
    }

    public Integer verificarCamelos1() {
        this.qtd1 = this.qtdtotal / 2;
        this.r1 = Math.round(this.qtd1);
        return(this.r1);
    }

    public Integer verificarCamelos2() {
        this.qtd2 = this.qtdtotal / 3;
        this.r2 = Math.round(this.qtd2);
        return(this.r2);
    }

    public Integer verificarCamelos3(){
        this.qtd3=this.qtdtotal/9;
        this.r3= Math.round(this.qtd3);
        return(this.r3);
    }
}