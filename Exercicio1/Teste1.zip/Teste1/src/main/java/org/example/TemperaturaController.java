package org.example;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SelectionModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class TemperaturaController {

    @FXML
    private ComboBox<String> cbmes;

    @FXML
    public void initialize() {
        cbmes.getItems().addAll("Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
    }

    @FXML
    private Label lbcidade;

    @FXML
    private Label lbtemperatura;

    @FXML
    private Label lbtipo;

    @FXML
    void Botao1(ActionEvent event) {
        Temperatura t1 = new Temperatura(cbmes.getValue());
        lbtemperatura.setText("A temperatura é: "+String.valueOf(t1.verificarTemperatura()));
        lbtipo.setText("A temperatura é agradável");
        lbcidade.setText(String.valueOf(t1.verificarcidade()));
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
