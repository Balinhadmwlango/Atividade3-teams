package org.example;

public class Temperatura {
    private double Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez,Med;
    private String r;

    public Temperatura(String r){
        this.r = r;
        this.Jan = 24.5;
        this.Fev = 25;
        this.Mar = 23.5;
        this.Abr = 21;
        this.Mai = 19;
        this.Jun = 18.5;
        this.Jul = 18.5;
        this.Ago = 20;
        this.Set = 21.5;
        this.Out = 22.5;
        this.Nov = 23.5;
        this.Dez = 24;
        this.Med = (this.Jan+this.Fev+this.Mar+this.Abr+this.Mai+this.Jun+this.Jul+this.Ago+this.Set+this.Out+this.Nov+this.Dez)/12;
    }

    public double verificarTemperatura() {
        double temp = 0.0;
        if (this.r == "Janeiro") {
            temp = this.Jan;
        } else if (this.r == "Fevereiro") {
            temp = this.Fev;
        } else if (this.r == "Março") {
            temp = this.Mar;
        } else if (this.r == "Abril") {
            temp = this.Abr;
        } else if (this.r == "Maio") {
            temp = this.Mai;
        } else if (this.r == "Junho") {
            temp = this.Jun;
        } else if (this.r == "Julho") {
            temp = this.Jul;
        } else if (this.r == "Agosto") {
            temp = this.Ago;
        } else if (this.r == "Setembro") {
            temp = this.Set;
        } else if (this.r == "Outubro") {
            temp = this.Out;
        } else if (this.r == "Novembro") {
            temp = this.Nov;
        } else if (this.r == "Dezembro"){
            temp = this.Dez;
        }
        return (temp);
    }

    public String verificarcidade(){
        if (this.Med<18){
            return ("São José dos Campos faz frio");
        }else{
            return ("São José dos Campos tem uma temperatura agradável");
        }
    }
}