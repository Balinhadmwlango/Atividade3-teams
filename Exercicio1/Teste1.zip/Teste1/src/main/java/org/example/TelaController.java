package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.IOException;

public class TelaController {

    @FXML
    void Botao1(ActionEvent event) throws IOException {
        App.setRoot("multiplo");
    }
    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("login");
    }
    @FXML
    void Botao3(ActionEvent event) throws IOException{
        App.setRoot("compra");
    }
    @FXML
    void Botao4(ActionEvent event) throws IOException{
        App.setRoot("temperatura");
    }
    @FXML
    void Botao5(ActionEvent event) throws IOException{
        App.setRoot("camelos");
    }
    @FXML
    void Botao6(ActionEvent event) throws IOException{
        App.setRoot("combustivel");
    }
    @FXML
    void Botao7(ActionEvent event) throws IOException {
        App.setRoot("aluguel");
    }

}
