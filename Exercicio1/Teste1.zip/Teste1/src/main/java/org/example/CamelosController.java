package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CamelosController {

    @FXML
    private TextField Texto1;

    @FXML
    private Label lbmeio;

    @FXML
    private Label lbnovo;

    @FXML
    private Label lbvelho;

    @FXML
    void Botao1(ActionEvent event) {
        Camelos c1 = new Camelos(Integer.parseInt(Texto1.getText()));
        lbvelho.setText("A quantidade de camelos do mais velho é: "+String.valueOf(c1.verificarCamelos1()));
        lbmeio.setText("A quantidade de camelos do meio é: "+String.valueOf(c1.verificarCamelos2()));
        lbnovo.setText("A quantidade de camelos do mais novo é: "+String.valueOf(c1.verificarCamelos3()));
        Texto1.clear();
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }
}
