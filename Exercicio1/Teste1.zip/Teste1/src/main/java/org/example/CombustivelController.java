package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CombustivelController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private Label lbpreco;

    @FXML
    void Botao1(ActionEvent event) {
        Combustivel c1 = new Combustivel(Double.parseDouble(Texto1.getText()),Double.parseDouble(Texto2.getText()));
        lbpreco.setText("Você irá pagar essa quantidade em combustível: R$ "+String.valueOf(c1.verificarCombustivel()));
        Texto1.clear();
        Texto2.clear();
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
