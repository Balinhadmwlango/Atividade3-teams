package org.example;

public class Compra {
    private double par, pfe, pol, pac, pca, pma, pfa, pfu, pmo, psa, soma, desc;

    public Compra(double par, double pfe, double pol, double pac, double pca, double pma, double pfa, double pfu, double pmo, double psa) {
        this.par = par;
        this.pfe = pfe;
        this.pol = pol;
        this.pac = pac;
        this.pca = pca;
        this.pma = pma;
        this.pfa = pfa;
        this.pfu = pfu;
        this.pmo = pmo;
        this.psa = psa;
        this.soma = 0;
        this.desc = 0;
    }

    public double verificarSoma() {
        this.soma = this.par + this.pfe + this.pol + this.pac + this.pca + this.pma + this.pfa + this.pfu + this.pmo + this.psa;
        return (this.soma);
    }

    public double verificarDesc() {
        if (this.soma > 100) {
            this.desc = this.soma / 10;
            this.desc = this.soma - this.desc;
        }
        return (this.desc);
    }
}
