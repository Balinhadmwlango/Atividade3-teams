package org.example;

public class Combustivel {
    private double km,L,Pcom,Tpcom,Des;

    public Combustivel(double km, double Pcom){
        this.km = km;
        this.Pcom = Pcom;
        this.L = 0;
        this.Tpcom = 0;
        this.Des = 0;
    }

    public double verificarCombustivel(){
        this.L=this.km/12;
        if(this.km<500){
            this.Tpcom=this.L*this.Pcom;
        }else{
            this.Des=(this.Pcom/10)/2;
            this.Tpcom=this.L*(this.Pcom-this.Des);
        }
        return (this.Tpcom);
    }
}
