package org.example;
public class Multiplo {
    private int n1;
    private int n2;

    public Multiplo(int n1, int n2) {
        this.n1 = n1;
        this.n2 = n2;
    }

    public String verificarMultiplo() {
        if (this.n2 == 0) {
            return("Não é possível dividir por zero.");
        } else if (this.n1 % this.n2 == 0) {
            return("O primeiro número é múltiplo do segundo.");
        } else {
            return("O primeiro número não é múltiplo do segundo.");
        }
    }
}
