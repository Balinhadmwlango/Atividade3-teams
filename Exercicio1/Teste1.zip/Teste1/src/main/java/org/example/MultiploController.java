package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;

public class MultiploController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private Label lbresultado;

    @FXML
    void Botao1(ActionEvent event) {
        Multiplo m1 = new Multiplo(Integer.parseInt(Texto1.getText()), Integer.parseInt(Texto2.getText()));
        lbresultado.setText(m1.verificarMultiplo());
        Texto1.clear();
        Texto2.clear();
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
