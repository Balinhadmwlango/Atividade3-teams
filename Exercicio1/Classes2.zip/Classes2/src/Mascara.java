public class Mascara {
}
