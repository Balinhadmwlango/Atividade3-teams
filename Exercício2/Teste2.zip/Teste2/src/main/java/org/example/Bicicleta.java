package org.example;

public class Bicicleta {
    private String tipo;
    private int dias,aro;

    public Bicicleta(String tipo, Integer aro, int dias) {
        this.tipo = tipo;
        this.aro = aro;
        this.dias = dias;
    }

    public Double calcularAluguel() {
        double valorDiaria = 0.0;

        if (this.tipo.equals("Mountain Bike")) {
            if (this.aro == 29) {
                valorDiaria = 80.0;
            } else if (this.aro == 27) {
                valorDiaria = 70.0;
            } else {
                valorDiaria = 60.0;
            }
        } else if (this.tipo.equals("Speed")) {
            valorDiaria = 90.0;
        } else {
            valorDiaria = 40.0;
        }

        return valorDiaria * this.dias;
    }
}