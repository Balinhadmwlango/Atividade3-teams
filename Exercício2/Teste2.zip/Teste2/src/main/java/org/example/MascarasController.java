package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class MascarasController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private TextField Texto3;

    @FXML
    private ComboBox<String> cbacervo;

    @FXML
    private ComboBox<String> cbmascara;

    @FXML
    private ComboBox<String> cbmaterial;

    @FXML
    private ComboBox<Integer> cbmin;

    @FXML
    private ComboBox<String> cbregiao;

    @FXML
    private ComboBox<String> cbvisitante;

    @FXML
    private Label lbduracao;

    @FXML
    private Label lbpreco;

    @FXML
    private Label lbvalor;

    public void initialize() {
        cbacervo.getItems().addAll("Raro","Historico","Popular");
        cbmascara.getItems().addAll("Festiva","Ritual","Decorativa");
        cbmaterial.getItems().addAll("Madeira","Argila","Metal","Bambu");
        cbmin.getItems().addAll(30,60,90,120,180,210,240);
        cbregiao.getItems().addAll("Norte","Nordeste","Centro-Oeste","Sudeste","Sul");
        cbvisitante.getItems().addAll("Estudante","Idoso","Professor","Crianca","Adulto");
    }

    @FXML
    void Botao1(ActionEvent event) {
        Mascara m1 = new Mascara(cbmascara.getValue(),cbmaterial.getValue(),Double.parseDouble(Texto3.getText()));
        Artesao a1 = new Artesao(Texto1.getText(),cbregiao.getValue(),Integer.parseInt(Texto2.getText()));
        Exposicao e1 = new Exposicao(cbacervo.getValue(),cbvisitante.getValue(),cbmin.getValue());
        lbpreco.setText("O valor da máscara é: R$"+String.valueOf(m1.calcularPreco()));
        lbvalor.setText("O valor da sua mão de obra custa: R$"+String.valueOf(a1.calcularMaoDeObra()));
        lbduracao.setText("E o ingresso para a exposição é: R$"+String.valueOf(e1.calcularIngresso()));
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
