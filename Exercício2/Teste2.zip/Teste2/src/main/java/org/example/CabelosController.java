package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class CabelosController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private TextField Texto3;

    @FXML
    private TextField Texto4;

    @FXML
    private ComboBox<String> cbcargo;

    @FXML
    private ComboBox<String> cbdificuldade;

    @FXML
    private ComboBox<String> cbespecializacao;

    @FXML
    private ComboBox<String> cbformato;

    @FXML
    private ComboBox<String> cbplano;

    @FXML
    private Label lbpacote;

    @FXML
    private Label lbpreco;

    @FXML
    private Label lbsalario;

    public void initialize() {
        cbcargo.getItems().addAll("Junior","Pleno","Senior");
        cbdificuldade.getItems().addAll("Facil","Medio","Dificil");
        cbespecializacao.getItems().addAll("Corte","Coloracao");
        cbformato.getItems().addAll("Liso","Ondulado","Cacheado","Crespo");
        cbplano.getItems().addAll("Mensal","Trimestral","Anual");
    }

    @FXML
    void Botao1(ActionEvent event) {
        Corte c1 = new Corte(Texto2.getText(),cbdificuldade.getValue(),Texto3.getText());
        Cliente cl1 = new Cliente(cbformato.getValue(),cbplano.getValue(),Integer.parseInt(Texto1.getText()));
        Atendimentos a1 = new Atendimentos(cbcargo.getValue(),cbespecializacao.getValue(),Integer.parseInt(Texto4.getText()));
        lbpreco.setText("O preço do corte será de: R$"+String.valueOf(c1.calcularPreco()));
        lbpacote.setText("O pacote do cliente sairá por: R$"+String.valueOf(cl1.calcularPacote()));
        lbsalario.setText("Seu salário sairá em torno de: R$"+String.valueOf(a1.calcularSalario()));
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
