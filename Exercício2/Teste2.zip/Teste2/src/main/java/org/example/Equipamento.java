package org.example;

public class Equipamento {
    private String item, tamanho;
    private int quantidade;

    public Equipamento(String item, String tamanho, int quantidade) {
        this.item = item;
        this.tamanho = tamanho;
        this.quantidade = quantidade;
    }

    public Double calcularTotal() {
        double precoUnitario = 0.0;

        if (this.item.equals("Capacete")) {
            if (this.tamanho.equals("P")) {
                precoUnitario = 120.0;
            } else if (this.tamanho.equals("M")) {
                precoUnitario = 140.0;
            } else if (this.tamanho.equals("G")) {
                precoUnitario = 160.0;
            }
        } else if (this.item.equals("Luva")) {
            if (this.tamanho.equals("P")) {
                precoUnitario = 40.0;
            } else if (this.tamanho.equals("M")) {
                precoUnitario = 50.0;
            } else if (this.tamanho.equals("G")) {
                precoUnitario = 60.0;
            }
        } else if (this.item.equals("Oculos")) {
            precoUnitario = 90.0;
        } else {
            precoUnitario = 20.0;
        }

        return precoUnitario * this.quantidade;
    }
}