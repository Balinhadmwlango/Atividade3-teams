package org.example;

public class Atendimentos {
    private String cargo, especialidade;
    private int atendimento;

    public Atendimentos(String cargo, String especialidade, int atendimento) {
        this.cargo = cargo;
        this.especialidade = especialidade;
        this.atendimento = atendimento;
    }

    public Double calcularSalario() {
        double salarioBase = 0.0;

        if (this.cargo.equals("Junior")) {
            salarioBase = 1500.0;
        } else if (this.cargo.equals("Pleno")) {
            salarioBase = 2500.0;
        } else if (this.cargo.equals("Senior")) {
            salarioBase = 4000.0;
        } else {
            salarioBase = 1200.0;
        }

        if (this.especialidade.equals("Corte")) {
            salarioBase = salarioBase + 500.0;
        } else if (this.especialidade.equals("Coloracao")) {
            salarioBase = salarioBase + 300.0;
        }

        salarioBase = salarioBase + (this.atendimento * 10.0);

        return salarioBase;
    }
}