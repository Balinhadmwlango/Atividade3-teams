package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.IOException;

public class TelaController {

    @FXML
    void Botao1(ActionEvent event) throws IOException{
        App.setRoot("loja");
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException{
        App.setRoot("trilha");
    }

    @FXML
    void Botao3(ActionEvent event) throws IOException{
        App.setRoot("mascara");
    }

    @FXML
    void Botao4(ActionEvent event) throws IOException{
        App.setRoot("cabelo");
    }

}
