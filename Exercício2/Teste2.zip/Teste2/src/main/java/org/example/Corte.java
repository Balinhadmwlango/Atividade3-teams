package org.example;

public class Corte {
    private String estilo, dificuldade;
    private String comFranja;

    public Corte(String estilo, String dificuldade, String comFranja) {
        this.estilo = estilo;
        this.dificuldade = dificuldade;
        this.comFranja = comFranja;
    }

    public Double calcularPreco() {
        double preco = 0.0;

        if (this.dificuldade.equals("Facil")) {
            preco = 30.0;
        } else if (this.dificuldade.equals("Medio")) {
            preco = 50.0;
        } else if (this.dificuldade.equals("Dificil")) {
            preco = 80.0;
        } else {
            preco = 20.0;
        }

        if (this.estilo.equals("Spiky") || this.estilo.equals("Emo")) {
            preco = preco + 20.0;
        } else if (this.estilo.equals("Social")) {
            preco = preco + 5.0;
        } else{
            preco = preco + 2.0;
        }

        if ((this.comFranja.equals("Sim"))||(this.comFranja.equals("sim"))) {
            preco = preco + 10.0;
        }

        return preco;
    }
}