package org.example;

public class Exposicao {
    private String acervo, visitante;
    private int duracaoMin;

    public Exposicao(String acervo, String visitante, int duracaoMin) {
        this.acervo = acervo;
        this.visitante = visitante;
        this.duracaoMin = duracaoMin;
    }

    public Double calcularIngresso() {
        double valor = 0.0;

        if (this.acervo.equals("Raro")) {
            valor = 60.0;
        } else if (this.acervo.equals("Historico")) {
            valor = 40.0;
        } else if (this.acervo.equals("Popular")) {
            valor = 25.0;
        }

        if (this.visitante.equals("Estudante")) {
            valor = valor - (valor * 0.50);
        } else if (this.visitante.equals("Idoso")) {
            valor = valor - (valor * 0.30);
        } else if (this.visitante.equals("Professor")) {
            valor = valor - (valor * 0.20);
        } else if (this.visitante.equals("Crianca")){
            valor = valor - (valor * 0.10);
        }

        if (this.duracaoMin > 90) {
            valor = valor + 10.0;
        }

        return valor;
    }
}