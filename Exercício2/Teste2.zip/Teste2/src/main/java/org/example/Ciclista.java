package org.example;

public class Ciclista {
    private String nome, nivel;
    private int idade;

    public Ciclista(String nome, String nivel, int idade) {
        this.nome = nome;
        this.nivel = nivel;
        this.idade = idade;
    }

    public Double calcularPlano() {
        double valor = 0.0;

        if (this.nivel.equals("Iniciante")) {
            valor = 50.0;
        } else if (this.nivel.equals("Intermediario")) {
            valor = 80.0;
        } else if (this.nivel.equals("Profissional")) {
            valor = 120.0;
        } else {
            valor = 30.0;
        }

        if (this.idade < 18 || this.idade > 60) {
            valor = valor - (valor * 0.10);
        }

        return valor;
    }
}