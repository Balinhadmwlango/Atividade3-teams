package org.example;

public class Camiseta {
    private String cor,tecido,tamanho;

    public Camiseta(String cor, String tecido, String tamanho) {
        this.cor = cor;
        this.tecido = tecido;
        this.tamanho = tamanho;
    }

    public String verificarcamiseta() {
        return ("Camiseta "+this.cor+" feita de "+this.tecido+" tamanho "+this.tamanho);
    }
}