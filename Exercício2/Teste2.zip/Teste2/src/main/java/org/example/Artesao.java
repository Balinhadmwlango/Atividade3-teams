package org.example;

public class Artesao {
    private String nome, regiao;
    private int anosExperiencia;

    public Artesao(String nome, String regiao, int anosExperiencia) {
        this.nome = nome;
        this.regiao = regiao;
        this.anosExperiencia = anosExperiencia;
    }

    public Double calcularMaoDeObra() {
        double valorBase = 0.0;

        if (this.regiao.equals("Norte")) {
            valorBase = 100.0;
        } else if (this.regiao.equals("Nordeste")) {
            valorBase = 120.0;
        } else if (this.regiao.equals("Sudeste")) {
            valorBase = 150.0;
        } else {
            valorBase = 80.0;
        }

        if (this.anosExperiencia >= 20) {
            valorBase = valorBase + 200.0;
        } else if (this.anosExperiencia >= 10) {
            valorBase = valorBase + 100.0;
        } else if (this.anosExperiencia >= 5) {
            valorBase = valorBase + 50.0;
        }

        return valorBase;
    }
}