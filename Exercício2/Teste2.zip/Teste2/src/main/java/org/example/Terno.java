package org.example;

public class Terno {
    private String cor,tecido,tamanho;

    public Terno(String cor, String tecido, String tamanho) {
        this.cor = cor;
        this.tecido = tecido;
        this.tamanho = tamanho;
    }

    public String verificarterno() {
        return ("Terno "+this.cor+" feito de "+this.tecido+" tamanho "+this.tamanho);
    }
}