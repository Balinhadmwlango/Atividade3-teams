package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

public class TrilhaController {

    @FXML
    private TextField Texto1;

    @FXML
    private TextField Texto2;

    @FXML
    private TextField Texto3;

    @FXML
    private ComboBox<Integer> cbaro;

    @FXML
    private ComboBox<String> cbbike;

    @FXML
    private ComboBox<String> cbequip;

    @FXML
    private ComboBox<String> cbintensidade;

    @FXML
    private ComboBox<Integer> cbqtd;

    @FXML
    private ComboBox<String> cbtam;

    @FXML
    private Label lbaluguel;

    @FXML
    private Label lbequipamento;

    @FXML
    private Label lbplano;

    public void initialize() {
        cbaro.getItems().addAll(16, 20, 24, 27, 29);
        cbbike.getItems().addAll("Mountain Bike", "Speed", "Passeio", "Eletrico");
        cbequip.getItems().addAll("Capacete","Luva","Oculos","Joelheira");
        cbintensidade.getItems().addAll("Iniciante","Intermediario","Profissional");
        cbqtd.getItems().addAll(1,2,3,4,5,6,7,8);
        cbtam.getItems().addAll("P", "M", "G");
    }

    @FXML
    void Botao1(ActionEvent event) {
        Bicicleta b1 = new Bicicleta(cbbike.getValue(),cbaro.getValue(),Integer.parseInt(Texto3.getText()));
        Ciclista c1 = new Ciclista(Texto1.getText(),cbintensidade.getValue(),Integer.parseInt(Texto2.getText()));
        Equipamento e1 = new Equipamento(cbequip.getValue(),cbtam.getValue(),cbqtd.getValue());
        lbaluguel.setText("O aluguel da bibicleta ficou em: R$"+String.valueOf(b1.calcularAluguel()));
        lbplano.setText("O seu plano vai custar: R$"+String.valueOf(c1.calcularPlano()));
        lbequipamento.setText("O seu equipamento vai custar: R$"+String.valueOf(e1.calcularTotal()));
    }

    @FXML
    void Botao2(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

}
