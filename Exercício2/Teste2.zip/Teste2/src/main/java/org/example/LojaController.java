package org.example;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;

import java.io.IOException;

public class LojaController {

    @FXML
    private ComboBox<String> cbcor;

    @FXML
    private ComboBox<String> cbpeca;

    @FXML
    private ComboBox<String> cbtam;

    @FXML
    private ComboBox<String> cbtecido;


    @FXML
    private Label lbcompra;

    @FXML
    private Label lbfinal;

    @FXML
    private Label lbpeca;

    @FXML
    private Label lbpreco;

    @FXML
    private Button Botao2;

    @FXML
    private Button Botao4;

    public void initialize() {
        cbcor.getItems().addAll("preto","azul","branco","cinza");
        cbpeca.getItems().addAll("Terno","Camiseta");
        cbtam.getItems().addAll("P","M","G","GG");
        cbtecido.getItems().addAll("poliéster","algodão","lã fria","linho");
        Botao2.setVisible(false);
        Botao2.setManaged(false);
        Botao4.setVisible(false);
        Botao4.setManaged(false);
    }

    @FXML
    void Botao1(ActionEvent event) {
        Produto p1 = new Produto(cbpeca.getValue(),cbtam.getValue());
        if (cbpeca.getValue() == "Terno"){
            Terno t1 = new Terno(cbcor.getValue(),cbtecido.getValue(),cbtam.getValue());
            lbpeca.setText(t1.verificarterno());
            lbpreco.setText("O preço desse terno é: R$"+String.valueOf(p1.verificarroupa()));
            lbcompra.setText("Deseja comprar?");
            Botao2.setVisible(true);
            Botao2.setManaged(true);
            Botao4.setVisible(false);
            Botao4.setManaged(false);
        }else{
            Camiseta c1 = new Camiseta(cbcor.getValue(),cbtecido.getValue(),cbtam.getValue());
            lbpeca.setText(c1.verificarcamiseta());
            lbpreco.setText("O preço dessa camiseta é: R$"+String.valueOf(p1.verificarroupa()));
            lbcompra.setText("Deseja comprar?");
            Botao2.setVisible(true);
            Botao2.setManaged(true);
            Botao4.setVisible(true);
            Botao4.setManaged(true);
        }
    }

    @FXML
    void Botao2(ActionEvent event) {
        lbfinal.setText("Finalizada a compra com sucesso!");
    }

    @FXML
    void Botao3(ActionEvent event) throws IOException {
        App.setRoot("tela");
    }

    @FXML
    void Botao4(ActionEvent event) {
        lbfinal.setText("Poxa que pena, até outro dia!");

    }


}

