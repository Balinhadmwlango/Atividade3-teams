package org.example;

public class Mascara {
    private String tipo, material;
    private double alturaCm;

    public Mascara(String tipo, String material, double alturaCm) {
        this.tipo = tipo;
        this.material = material;
        this.alturaCm = alturaCm;
    }

    public Double calcularPreco() {
        double preco = 0.0;

        if (this.tipo.equals("Ritual")) {
            if (this.material.equals("Madeira")) {
                preco = 350.0;
            } else if (this.material.equals("Argila")) {
                preco = 280.0;
            } else {
                preco = 200.0;
            }
        } else if (this.tipo.equals("Decorativa")) {
            if (this.material.equals("Madeira")) {
                preco = 180.0;
            } else if (this.material.equals("Metal")) {
                preco = 220.0;
            } else {
                preco = 120.0;
            }
        } else {
            preco = 90.0;
        }

        if (this.alturaCm > 50.0) {
            preco = preco + (preco * 0.20);
        }

        return preco;
    }
}