package org.example;

public class Cliente {
    private String tipoCabelo, plano;
    private int idade;

    public Cliente(String tipoCabelo, String plano, int idade) {
        this.tipoCabelo = tipoCabelo;
        this.plano = plano;
        this.idade = idade;
    }

    public Double calcularPacote() {
        double valor = 0.0;

        if (this.tipoCabelo.equals("Liso")) {
            valor = 40.0;
        } else if (this.tipoCabelo.equals("Ondulado")) {
            valor = 55.0;
        } else if (this.tipoCabelo.equals("Cacheado")) {
            valor = 70.0;
        } else if (this.tipoCabelo.equals("Crespo")) {
            valor = 90.0;
        }

        if (this.plano.equals("Mensal")) {
            valor = valor - (valor * 0.15);
        } else if (this.plano.equals("Trimestral")) {
            valor = valor - (valor * 0.30);
        } else if (this.plano.equals("Anual")){
            valor = valor - (valor * 0.45);
        }

        if (this.idade < 12) {
            valor = valor - (valor * 0.50);
        }

        return valor;
    }
}