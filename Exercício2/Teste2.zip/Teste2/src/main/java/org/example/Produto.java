package org.example;

public class Produto {
    private String peca,tamanho;
    private double preco;

    public Produto(String peca, String tamanho) {
        this.peca = peca;
        this.preco = 0.0;
        this.tamanho = tamanho;
    }

    public Double verificarroupa() {
        if (this.peca == "Terno"){
            if(this.tamanho == "P"){
                this.preco = 150.0;
            }else if (this.tamanho == "M"){
                this.preco = 155.0;
            }else if (this.tamanho == "G"){
                this.preco = 160.0;
            }else if (this.tamanho == "GG"){
                this.preco = 170.0;
            }
        }else{
            if(this.tamanho == "P"){
                this.preco = 50.0;
            }else if (this.tamanho == "M"){
                this.preco = 60.0;
            }else if (this.tamanho == "G"){
                this.preco = 70.0;
            }else if (this.tamanho == "GG"){
                this.preco = 80.0;
            }
        }
        return (this.preco);
    }
}